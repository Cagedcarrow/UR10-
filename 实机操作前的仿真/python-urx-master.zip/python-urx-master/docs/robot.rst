
Robot Object
=========================================

.. autoclass:: urx.robot.Robot
   :members:
   :undoc-members:

   .. autoattribute: 

